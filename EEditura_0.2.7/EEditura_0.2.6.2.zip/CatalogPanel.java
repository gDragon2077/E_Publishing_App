import javax.swing.*;
import java.awt.*;
import java.util.List;

public class CatalogPanel extends JPanel {
    private ShoppingCart cart;
    private MainFrame mainFrame;

    public CatalogPanel(List<Book> books, ShoppingCart cart, MainFrame mainFrame) {
        this.cart = cart;
        this.mainFrame = mainFrame;

        setLayout(new BorderLayout());

        JPanel container = new JPanel();
        container.setLayout(new WrapLayout(FlowLayout.LEFT, 10, 10)); // responsive

        for (Book book : books) {
            container.add(createBookCard(book));
        }

        add(container, BorderLayout.CENTER);
    }

    private JPanel createBookCard(Book book) {
        JPanel card = new JPanel();
        card.setPreferredSize(new Dimension(200, 250));
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        card.setBackground(Color.WHITE);

        JLabel titleLabel = new JLabel("<html><center>" + book.getTitle() + "</center></html>");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 13));
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel authorLabel = new JLabel("<html><center>" + book.getAuthor() + "</center></html>");
        authorLabel.setFont(new Font("Arial", Font.PLAIN, 11));
        authorLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel priceLabel = new JLabel("Price: " + book.getPrice() + " RON");
        priceLabel.setFont(new Font("Arial", Font.PLAIN, 11));
        priceLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel yearLabel = new JLabel("Year: " + book.getYear());
        yearLabel.setFont(new Font("Arial", Font.PLAIN, 11));
        yearLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JTextArea reviewsArea = new JTextArea();
        reviewsArea.setEditable(false);
        reviewsArea.setBackground(new Color(245, 245, 245));
        reviewsArea.setFont(new Font("Arial", Font.ITALIC, 10));
        reviewsArea.setLineWrap(true);
        reviewsArea.setWrapStyleWord(true);
        reviewsArea.setBorder(null);
        reviewsArea.setMaximumSize(new Dimension(180, 70));
        reviewsArea.setText(buildReviewText(book.getReviews()));

        JButton addButton = new JButton("Add to cart");
        addButton.setFont(new Font("Arial", Font.PLAIN, 11));
        addButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        addButton.addActionListener(e -> {
            cart.addBook(book);
            int totalItems = cart.getTotalItemCount();
            /// mainFrame.updateCartCount(totalItems); // actualizeaza contor
            JOptionPane.showMessageDialog(this, "Book added: " + book.getTitle());
        });

        card.add(Box.createVerticalStrut(5));
        card.add(titleLabel);
        card.add(authorLabel);
        card.add(priceLabel);
        card.add(yearLabel);
        card.add(Box.createVerticalStrut(5));
        card.add(reviewsArea);
        card.add(Box.createVerticalStrut(5));
        card.add(addButton);

        return card;
    }

    private String buildReviewText(List<String> reviews) {
        StringBuilder sb = new StringBuilder("Reviews:\n");
        for (String review : reviews) {
            if (!review.isBlank()) {
                sb.append("• ").append(review).append("\n");
            }
        }
        return sb.toString();
    }
}
