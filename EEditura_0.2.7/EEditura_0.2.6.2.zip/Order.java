import java.util.Date;
import java.util.List;

public class Order {
    private Client client;
    private List<CartItem> items;
    private DeliveryType delivery;
    private Payment payment;
    private Date date;
    private Date orderDate;
    private DeliveryType deliveryType;

    // Constructorul primeste toate informatiile despre comanda
    public Order(Client client, List<CartItem> items, DeliveryType delivery, Payment payment, Date date) {
        this.client = client;
        this.items = items;
        this.delivery = delivery;
        this.payment = payment;
        this.date = date;
    }

    // Returneaza clientul care a facut comanda
    public Client getClient() {
        return client;
    }

    public Date getOrderDate() {
        return orderDate;
    }
    
    public DeliveryType getDeliveryType() {
        return deliveryType;
    }    

    // Returneaza lista de CartItem (carte + cantitate)
    public List<CartItem> getItems() {
        return items;
    }

    // Returneaza tipul de livrare
    public DeliveryType getDelivery() {
        return delivery;
    }

    // Returneaza obiectul Payment asociat
    public Payment getPayment() {
        return payment;
    }

    // Returneaza data comenzii
    public Date getDate() {
        return date;
    }

    // Calculeaza totalul comenzii (carti + livrare)
    public double getTotal() {
        double total = 0.0;
        for (CartItem item : items) {
            total += item.getBook().getPrice() * item.getQuantity();
        }

        // Adauga taxa suplimentara daca este livrare EXPRESS
        if (delivery == DeliveryType.EXPRESS) {
            total += 5.0;
        }

        return total;
    }
}
