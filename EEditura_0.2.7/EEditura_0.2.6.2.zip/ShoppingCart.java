import java.util.ArrayList;
import java.util.List;

public class ShoppingCart {
    private List<CartItem> items;

    public ShoppingCart() {
        this.items = new ArrayList<>();
    }

    // Adauga cartea in cos; daca exista deja, creste cantitatea
    public void addBook(Book book) {
        for (CartItem item : items) {
            if (item.getBook().getTitle().equals(book.getTitle())) {
                item.incrementQuantity();
                return;
            }
        }
        items.add(new CartItem(book));
    }

    // Returneaza lista itemelor unice
    public List<CartItem> getItems() {
        return items;
    }

    // Returneaza numarul total de carti din cos (cu cantitati)
    public int getTotalItemCount() {
        int total = 0;
        for (CartItem item : items) {
            total += item.getQuantity();
        }
        return total;
    }

    // Goleste cosul
    public void clear() {
        items.clear();
    }

    // Returneaza valoarea totala a produselor (fara taxe de livrare)
    public double getTotal() {
        double total = 0.0;
        for (CartItem item : items) {
            total += item.getBook().getPrice() * item.getQuantity();
        }
        return total;
    }

}
