import java.util.List;

// Clasa Book reprezinta o carte din catalog
public class Book {
    private String title;
    private String author;
    private int year;
    private int pages;
    private double price;
    private int deliveryTime;
    private List<String> reviews; // Lista de recenzii, maxim 5

    // Constructorul principal
    public Book(String title, String author, int year, int pages, double price, int deliveryTime, List<String> reviews) {
        this.title = title;
        this.author = author;
        this.year = year;
        this.pages = pages;
        this.price = price;
        this.deliveryTime = deliveryTime;
        this.reviews = reviews; // Salvam lista de recenzii
    }

    // Getteri si setteri
    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public int getYear() {
        return year;
    }

    public int getPages() {
        return pages;
    }

    public double getPrice() {
        return price;
    }

    public int getDeliveryTime() {
        return deliveryTime;
    }

    public List<String> getReviews() {
        return reviews;
    }

    public void setReviews(List<String> reviews) {
        this.reviews = reviews;
    }
}
